package com.arc.nio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NioApplicationTests {

    @Test
    void contextLoads() {
    }

}
